#1usr/bin/env python3

from tf import TransformBroadcaster 
import rospy
from rospy import Time 


def main():
	rospy.init_node('my_bro')
	b = TransformBroadcaster()
	translation = (0.6,0.8,0.6)
	rotation = (0.0,0.0,0.0,1.0)
	rate = rospy.Rate(5)
	while not rospy.is_shutdown():
		b.sendTransform(translation,rotation,Time.now(),'rbh','/world')
		rate.sleep()



if __name__ =='__main__' :
	main()